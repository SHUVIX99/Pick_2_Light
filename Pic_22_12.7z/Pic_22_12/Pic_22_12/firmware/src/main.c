/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "stdio.h"
#define _XTAL_FREQ 200000000UL
#define ID_GateWay 0x10
uint16_t ID_Module;
uint8_t CAN_Write_1[8];
uint8_t CAN_Write_2[8];
//uint8_t CAN_Write_1[8]={0x01,0x00,0x01,0x02,0x00,0x00,0x05,0x03};
//uint8_t CAN_Write_2[8]={0x04,0x00,0x01,0xA5,0x4E,0xA4,0xAC,0xE3};
uint32_t CAN_ID_Receive;
uint8_t CAN_DATA_Receive[8];
uint8_t Start_CAN=0;
//uint8_t flag=0;
uint16_t Arr_CAN[100][2];
uint8_t Arr_CAN_index=0;
uint16_t idtemp;

void Set_CAN_Mess();
void Wait2SendCAN();
void Check_Module();
void Arr_Soft(uint8_t x);
void __delay_ms(uint32_t delay) {
    register uint32_t startCntms = _CP0_GET_COUNT();
    register uint32_t waitCntms = delay * (_XTAL_FREQ / 1000 / 2); //core timer runs at half of system clock

    while (_CP0_GET_COUNT() - startCntms < waitCntms);
}
void fifo0(uintptr_t context){
    printf("fifo0\r\n");
}
void fifo1(uintptr_t context){
//    printf("________RECEIVE_SUCCESS_____ \r\n");
//    printf("CAN ID %x : %x  %x  %x  %x  %x  %x  %x  %x\r\n",CAN_ID_Receive,CAN_DATA_Receive[0],CAN_DATA_Receive[1],CAN_DATA_Receive[2],CAN_DATA_Receive[3],CAN_DATA_Receive[4],CAN_DATA_Receive[5],CAN_DATA_Receive[6],CAN_DATA_Receive[7]);

    if(CAN_ID_Receive == ID_GateWay)
	{

//		if(CAN_DATA_Receive[0]==0x26)
//		{
//
//			if(CAN_DATA_Receive[1]==0x21)
//			{
//
//				flag=1;
//			}
//			else if(CAN_DATA_Receive[1]==0x23)
//			{
//
//				flag=0;
//			}
//		}
//		else if(CAN_DATA_Receive[0]==0x27)
//		{
//
//			if(CAN_DATA_Receive[1]==0x22)
//			{
//
//				flag=2;
//			}
//			else if(CAN_DATA_Receive[1]==0x24)
//			{
//
//				flag=1;
//			}
//		}
         if(CAN_DATA_Receive[0]==0x28 && CAN_DATA_Receive[1]==0x25)
        {
//            flag=0;
             
             idtemp=(uint8_t)CAN_DATA_Receive[3];
            idtemp|=(uint8_t)CAN_DATA_Receive[2]<<8;
            if(idtemp>999)
            {
                printf("[OverMessage][IDCAN][%d]\r\n",idtemp);
            }
            else if(idtemp>99)
            {
                printf("[OverMessage][IDCAN][0%d]\r\n",idtemp);
            }
               else if(idtemp>9)
            {
                printf("[OverMessage][IDCAN][00%d]\r\n",idtemp);
            }
               else
            {
                printf("[OverMessage][IDCAN][000%d]\r\n",idtemp);
            }
        }
        else if(CAN_DATA_Receive[0]==0x55 && CAN_DATA_Receive[1]==0x54)
        {
            
            idtemp=((CAN_DATA_Receive[2]<<8)|CAN_DATA_Receive[3]);
                            if(idtemp>999)
            {
                printf("[Confirm][IDCAN][%d][ID][%d]\n\r",idtemp,CAN_DATA_Receive[4]);
            }
            else if(idtemp>99)
            {
                printf("[Confirm][IDCAN][0%d][ID][%d]\n\r",idtemp,CAN_DATA_Receive[4]);
            }
               else if(idtemp>9)
            {
                printf("[Confirm][IDCAN][00%d][ID][%d]\n\r",idtemp,CAN_DATA_Receive[4]);
            }
               else
            {
                printf("[Confirm][IDCAN][000%d][ID][%d]\n\r",idtemp,CAN_DATA_Receive[4]);
            }
            
//            flag=0;
            for(uint8_t i=0;i<Arr_CAN_index;i++)
            {
                if(Arr_CAN[i][0]==((CAN_DATA_Receive[2]<<8)|CAN_DATA_Receive[3]) &&
                Arr_CAN[i][1]==CAN_DATA_Receive[4])
                {
                    Arr_Soft(i);
                    i=200;
                }
            }
        }
	}
    
}
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );

    printf("_________DEMO CAN_________________\r\n");
    printf("_________DEMO CAN_________________\r\n");
    printf("_________DEMO CAN_________________\r\n");
    Set_CAN_Mess();
    CAN2_CallbackRegister(fifo1,0,1);

    while ( true )
    {

        printf("Wait\r\n");
//        CAN2_MessageTransmit(0,8,CAN_Write_1,0,CAN_MSG_TX_DATA_FRAME);
        Check_Module();
        __delay_ms(500);
        Wait2SendCAN();
			
            
		
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}
void Check_Module()
{
    if(Arr_CAN_index==0)
    {
        //turn off lamp
        printf("Turn off lamp\r\n");
        GPIO_RJ13_Set();
    }
    else
    {
        //turn on lamp
        printf("Turn on lamp\r\n");
        GPIO_RJ13_Clear();
    }
}
void Arr_Soft(uint8_t x)
{
    Arr_CAN[x][0]=0;
    Arr_CAN[x][1]=0;
    for(uint8_t i=x;i<Arr_CAN_index;i++)
    {
        Arr_CAN[i][0]=Arr_CAN[i+1][0];
        Arr_CAN[i][1]=Arr_CAN[i+1][1];
    }
    Arr_CAN_index--;
}
void Wait2SendCAN()
{

    
    while(Start_CAN==1)
			{
			
                    for(uint8_t i=0;i<10;i++)
                    {    
                        printf("Send %d\r\n",ID_Module);
                        if(CAN2_MessageTransmit(ID_Module,8,CAN_Write_1,0,CAN_MSG_TX_DATA_FRAME)==true)
                        {
                            //
                            if(ID_Module>999)
                            printf("[Positive_CAN_ID_1][%d]\r\n",ID_Module);
                            else if(ID_Module>99)
                            printf("[Positive_CAN_ID_1][0%d]\r\n",ID_Module);
                            else if(ID_Module>9)
                            printf("[Positive_CAN_ID_1][00%d]\r\n",ID_Module);
                            else 
                            printf("[Positive_CAN_ID_1][000%d]\r\n",ID_Module);
                            //
                            __delay_ms(20);
                            if(CAN2_MessageTransmit(ID_Module,8,CAN_Write_2,0,CAN_MSG_TX_DATA_FRAME)==true)
                            {
                                i=10;
                                Start_CAN=0;
                                //
                                if(ID_Module>999)
                                printf("[Positive_CAN_ID_2][%d]\r\n",ID_Module);
                                else if(ID_Module>99)
                                printf("[Positive_CAN_ID_2][0%d]\r\n",ID_Module);
                                else if(ID_Module>9)
                                printf("[Positive_CAN_ID_2][00%d]\r\n",ID_Module);
                                else 
                                printf("[Positive_CAN_ID_2][000%d]\r\n",ID_Module);
                                //
                                __delay_ms(10);
                                if(ID_Module>999)
                                {
                                    printf("[IDCAN][%d][ID][%d][OK]\r\n",ID_Module,CAN_Write_1[2]);
                                }
                                else if(ID_Module>99)
                                {
                                    printf("[IDCAN][0%d][ID][%d][OK]\r\n",ID_Module,CAN_Write_1[2]);
                                }
                                else if(ID_Module>9)
                                {
                                    printf("[IDCAN][00%d][ID][%d][OK]\r\n",ID_Module,CAN_Write_1[2]);
                                }
                                else
                                {
                                    printf("[IDCAN][000%d][ID][%d][OK]\r\n",ID_Module,CAN_Write_1[2]);
                                }
                              //[IDCAN][17][ID][1]\r\n
                                Arr_CAN[Arr_CAN_index][0]=ID_Module;
                                Arr_CAN[Arr_CAN_index][1]=CAN_Write_1[2];
                                Arr_CAN_index++;

                            } 
                            else
                            {
                                __delay_ms(150);
                            }
                        }
                        else
                        {
                            __delay_ms(150);
                        }
                        
                        if(i==9)
                        {
                            Start_CAN=0;
                            if(ID_Module>999)
                            printf("[Negative_CAN_ID][%d]\r\n",ID_Module);
                            else if(ID_Module>99)
                            printf("[Negative_CAN_ID][0%d]\r\n",ID_Module);
                            if(ID_Module>9)
                            printf("[Negative_CAN_ID][00%d]\r\n",ID_Module);
                            else
                            printf("[Negative_CAN_ID][000%d]\r\n",ID_Module);
                        }
                        
                    }
	
			}
}
void Set_CAN_Mess()
{
    CAN_Write_1[0]=0x01;
    CAN_Write_1[3]=0x02;
    CAN_Write_1[7]=0x03;
    
    CAN_Write_2[0]=0x04;
    CAN_Write_2[7]=0x05;
}
/*******************************************************************************
 End of File
*/


