/*******************************************************************************
 System Interrupts File

  Company:
    Microchip Technology Inc.

  File Name:
    interrupt.c

  Summary:
    Interrupt vectors mapping

  Description:
    This file maps all the interrupt vectors to their corresponding
    implementations. If a particular module interrupt is used, then its ISR
    definition can be found in corresponding PLIB source file. If a module
    interrupt is not used, then its ISR implementation is mapped to dummy
    handler.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2018 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "interrupts.h"
#include "definitions.h"

#include <stdio.h>
#include <stdlib.h>

extern uint8_t CAN_DATA_Receive[8];
extern uint32_t CAN_ID_Receive;
extern uint8_t Start_CAN;
extern uint16_t ID_Module;
extern uint8_t CAN_Write_1[8];
extern uint8_t CAN_Write_2[8];
extern uint16_t Arr_CAN[100][2];
uint8_t length=8;
uint16_t time=1;
uint8_t temp=0;
char *rxAdd;
uint8_t rxIndex;
char RxBuff[200];
char RxData;

                char Temp_char[4];
               
                
                uint8_t SL_int;
                uint8_t ID_int;
                uint8_t RF1;
                uint8_t RF2;
                uint8_t RF3;
                uint8_t RF4;
                uint8_t RF5;
                uint8_t IO;
CAN_MSG_RX_ATTRIBUTE msgAttrtemp= CAN_MSG_RX_DATA_FRAME;
// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************


void CAN2_InterruptHandler( void );



/* All the handlers are defined here.  Each will call its PLIB-specific function. */
void __ISR(_UART1_FAULT_VECTOR, ipl1SRS) UART1_FAULT_Handler (void)
{
}

void __ISR(_UART1_RX_VECTOR, ipl1SRS) UART1_RX_Handler (void)
{
    if(UART1_ReceiverIsReady()==true)
    {
        RxData= (char)UART1_ReadByte();
        printf("%c",RxData);
        if(rxIndex==0)
        {

            for(uint8_t i=0;i<100;i++)
            {
                RxBuff[i]=0;
            }
        }
        if(RxData!=13)
        {
           
            RxBuff[rxIndex++]=RxData;
        }
        else
        {
           if(strstr(RxBuff, "[IDCAN]"))
            {
                uint8_t index;
                rxAdd=strstr(RxBuff, "[IDCAN]");
                index=(uint8_t)(rxAdd-RxBuff);
                Temp_char[0]=RxBuff[(index+8)];
                Temp_char[1]=RxBuff[(index+9)];
                Temp_char[2]=RxBuff[(index+10)];
                Temp_char[3]=RxBuff[(index+11)];
                ID_Module=atoi(Temp_char);
        
                Temp_char[0]=RxBuff[(index+18)];
                Temp_char[1]=RxBuff[(index+19)];
                Temp_char[2]=RxBuff[(index+20)];
                Temp_char[3]=RxBuff[(index+21)];
                SL_int=atoi(Temp_char);

                Temp_char[0]=RxBuff[(index+28)];
                Temp_char[1]=0;
                Temp_char[2]=0;
                Temp_char[3]=0;
                ID_int=atoi(Temp_char);
                
                Temp_char[0]=RxBuff[(index+37)];
                Temp_char[1]=RxBuff[(index+38)];
                Temp_char[2]=RxBuff[(index+39)];
                Temp_char[3]=0;
                RF1=atoi(Temp_char);

                Temp_char[0]=RxBuff[(index+41)];
                Temp_char[1]=RxBuff[(index+42)];
                Temp_char[2]=RxBuff[(index+43)];
                Temp_char[3]=0;
                RF2=atoi(Temp_char);
                
                Temp_char[0]=RxBuff[(index+45)];
                Temp_char[1]=RxBuff[(index+46)];
                Temp_char[2]=RxBuff[(index+47)];
                Temp_char[3]=0;
                RF3=atoi(Temp_char);

                Temp_char[0]=RxBuff[(index+49)];
                Temp_char[1]=RxBuff[(index+50)];
                Temp_char[2]=RxBuff[(index+51)];
                Temp_char[3]=0;
                RF4=atoi(Temp_char);

                Temp_char[0]=RxBuff[(index+53)];
                Temp_char[1]=RxBuff[(index+54)];
                Temp_char[2]=RxBuff[(index+55)];
                Temp_char[3]=0;
                RF5=atoi(Temp_char);
                
                Temp_char[0]=RxBuff[(index+62)];
                Temp_char[1]=0;
                Temp_char[2]=0;
                Temp_char[3]=0;
                IO=atoi(Temp_char);
                
               
                CAN_Write_1[1]=0;
                CAN_Write_1[2]=ID_int;
                CAN_Write_2[1]=ID_int;


                if(SL_int<256)
                {
                    CAN_Write_1[5]=0;
                    CAN_Write_1[6]=SL_int;
                }
                else 
                {
                    CAN_Write_1[5]=SL_int<<8;
                    CAN_Write_1[6]=(uint8_t)(SL_int&0xFF00);
                }
                CAN_Write_1[4]=IO;
                CAN_Write_2[2]=RF1;
                CAN_Write_2[3]=RF2;
                CAN_Write_2[4]=RF3;
                CAN_Write_2[5]=RF4;
                CAN_Write_2[6]=RF5;
                if(ID_Module>999)
                {
                    printf("[IDCAN][%d][OK]\r\n",ID_Module);
                }
                else if(ID_Module>99)
                {
                    printf("[IDCAN][0%d][OK]\r\n",ID_Module);
                }
                else if(ID_Module>9)  
                {
                    printf("[IDCAN][00%d][OK]\r\n",ID_Module);
                }
                else
                {
                    printf("[IDCAN][000%d][OK]\r\n",ID_Module);
                }
                
                Start_CAN=1;
//                printf("%d_",ID_Module);
//                printf("%d_",SL_int);
//                printf("%d_",ID_int);
//                printf("%d_",RF1);
//                printf("%d_",RF2);
//                printf("%d_",RF3);
//                printf("%d_",RF4);
//                printf("%d_",RF5);
//                printf("%d_",IO);
            }
            else 
            {
                 if(ID_Module>999)
                {
                    printf("[IDCAN][%d][NOTOK]",ID_Module);
                }
                else if(ID_Module>99)
                {
                    printf("[IDCAN][0%d][NOTOK]",ID_Module);
                }
                else if(ID_Module>9)  
                {
                    printf("[IDCAN][00%d][NOTOK]",ID_Module);
                }
                else
                {
                    printf("[IDCAN][000%d][NOTOK]",ID_Module);
                }
            }
            rxIndex=0;
        }
        
         IFS3bits.U1RXIF = 0; //clear flag
    }    
}

void __ISR(_UART1_TX_VECTOR, ipl1SRS) UART1_TX_Handler (void)
{
    
}

void __ISR(_CAN2_VECTOR, ipl1SRS) CAN2_Handler (void)
{
    
    CAN2_MessageReceive(&CAN_ID_Receive, &length, CAN_DATA_Receive, &time, 1,(CAN_MSG_RX_ATTRIBUTE*)&msgAttrtemp);
    CAN2_InterruptHandler();

}




/*******************************************************************************
 End of File
*/
