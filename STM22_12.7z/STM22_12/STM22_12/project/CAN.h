#ifndef _CAN_H_
#define _CAN_H_

#ifdef __cplusplus
 extern "C" {
#endif
#include "stm32f10x.h"

typedef struct
{
	uint16_t id_staff;
	uint16_t num_product;
	uint8_t id_rfid[5];
	uint8_t inorout;
}Message_Can;
void CAN_Configuration(void);
uint8_t CanWriteData(uint16_t ID,uint8_t *CAN_DATA,uint8_t length);
void NVIC_CAN_Configuration(void);
void soft_struct_id(void);
void clear_struct(uint8_t i);
uint8_t Check_Mess_can();
#ifdef __cplusplus
}
#endif

#endif
