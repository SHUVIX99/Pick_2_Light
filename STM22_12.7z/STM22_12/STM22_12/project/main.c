#include "main.h"


#define ID_GateWay 0x10
extern uint16_t ID_Module;
extern Message_Can mess_can[4];
extern uint8_t in_dex;
extern uint8_t RFID_Flag;
uint8_t inout_temp;
uint8_t index_temp;
uint8_t success_message_response[8] ={0x55,0x54};

////


int main(void)
{
	SysTick_Config(SystemCoreClock/1000);			// cau hinh systick ngat moi 1ms
	GPIO_Configuration_C_13();
	GPIO_Configuration_LED();
	Button_Configure();
	
		MFRC522_Init();
	UART_Configuration();
	printf("\r\n****************************************************************\r\n");
 	printf("CAN-Bus Test \r\n");
 	printf("CAN-Bus Speed 500kHz \r\n");
	CAN_Configuration();
	NVIC_CAN_Configuration();
	

		
ID_Staff(8888);
Num_Product(8888);
	
  while (1)
  {
		if(RFID_Flag == ENABLE)
		{
			ID_Staff(mess_can[0].id_staff+mess_can[1].id_staff*10+mess_can[2].id_staff*100+mess_can[3].id_staff*1000);
			Num_Product(0);
			status = MFRC522_Request(PICC_REQIDL, str);	
//			if (status == MI_OK)
//			{
//			printf("Find out a card: %x, %x\r\n",str[0],str[1]);
//			}

			//Chong va cham the, tra ve 5 byte ma the
			status = MFRC522_Anticoll(str);
			memcpy(serNum, str, 5);
			if (status == MI_OK)
			{
			printf("Your card's number are: %x, %x, %x, %x, %x \r\n",serNum[0], serNum[1], serNum[2], serNum[3],serNum[4]);
			
			
			for(int i=0;i<4;i++)
			{
				printf("Your Key's number are: %x, %x, %x, %x, %x \r\n",mess_can[i].id_rfid[0], mess_can[i].id_rfid[1], mess_can[i].id_rfid[2], mess_can[i].id_rfid[3],mess_can[i].id_rfid[4]);

					if(serNum[0]==mess_can[i].id_rfid[0] && serNum[1]==mess_can[i].id_rfid[1] && serNum[2]==mess_can[i].id_rfid[2] && serNum[3]==mess_can[i].id_rfid[3] && serNum[4]==mess_can[i].id_rfid[4])
				{
					printf("RFID OKE_________");
					RFID_Flag = DISABLE;

					index_temp=i;
				}  
			}
			}
			
		}
		if(RFID_Flag ==DISABLE)
		{
			
			if(mess_can[index_temp].inorout==0)
				{
					Led_red_on();			
				}
			else
				{
					Led_red_off();
				}
				Num_Product(mess_can[index_temp].num_product);
			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)==0)
			{
				while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)==0)
				{
					printf("button\r\n");
				}
				success_message_response[3]=(uint8_t)ID_Module;
				success_message_response[2]=(uint8_t)(ID_Module>>8);
				success_message_response[4]=(index_temp+1);
				for(uint8_t i=0;i<5;i++)
				{
					CanWriteData(ID_GateWay,success_message_response,5);
					Delay_ms(100);
				}
				clear_struct(index_temp);
				Led_red_off();
				RFID_Flag=ENABLE;
			}

		}
		
		
		
  }
}



