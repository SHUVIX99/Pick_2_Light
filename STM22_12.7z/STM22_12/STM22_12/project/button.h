#ifndef _BUTTON_H_
#define _BUTTON_H_

#ifdef __cplusplus
 extern "C" {
#endif
#include "stm32f10x.h"
uint8_t Read_Button(void);
void Button_Configure(void);
void Led_red_on(void);
void Led_red_off(void);
#ifdef __cplusplus
}
#endif

#endif
