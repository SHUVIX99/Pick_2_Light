#ifndef _LED_H_
#define _LED_H_

#ifdef __cplusplus
 extern "C" {
#endif
#include "stm32f10x.h"
typedef enum
{
	LED1=1,
	LED2=2,
	LED3=3,
	LED4=4,
	LED5=5,
	LED6=6,
	LED7=7,
	LED8=8
} LED_7_Seg;
void GPIO_Configuration_LED(void);
void LED_ON(LED_7_Seg ledon);
void Single(uint8_t num);
void ID_Staff(uint16_t num);
void Num_Product(uint16_t num);
void LED_OFF(void);
#ifdef __cplusplus
}
#endif

#endif
