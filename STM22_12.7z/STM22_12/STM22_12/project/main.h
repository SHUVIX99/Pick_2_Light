#ifndef _MAIN_H_
#define _MAIN_H_

#include "stm32f10x.h"
#include "Common.h"
#include "stdio.h"
#include "stm32f1_rc522.h"
#include "led.h"
#include "can.h"
#include "string.h"
#include "button.h"
GPIO_InitTypeDef 					GPIO_InitStructure;
USART_InitTypeDef			UART_InitStructure;
NVIC_InitTypeDef 					NVIC_InitStructure;

uint32_t Timingdelay;
//CAN
extern uint8_t CAN_ID_Receive;
extern uint8_t CAN_DATA_Receive[8];
extern uint8_t CanFlag;
 uchar i,tmp;
 uchar status;
 uchar str[MAX_LEN]; // Max_LEN = 16
 uchar serNum[5];
#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
//#define GETCHAR_PROTOTYPE int fgetc(FILE *f)
#endif /* __GNUC__ */
	
PUTCHAR_PROTOTYPE
{
	/* Place your implementation of fputc here */
  	/* e.g. write a character to the LCD */
	//lcd_Data_Write((u8)ch);
	USART_SendData(USART1,(u8)ch);
	
	/*Loop until the end of transmission */
	while (USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET)
{}

  	return ch;
}

#endif
