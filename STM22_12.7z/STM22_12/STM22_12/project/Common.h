#ifndef _COMMON_H_
#define _COMMON_H_

#ifdef __cplusplus
 extern "C" {
#endif
#include "stm32f10x.h"

void Delay_ms(uint16_t time);
void Delay_ms_sys(uint16_t time);
void Dms_sys_noint(uint16_t time);
void GPIO_Configuration_C_13(void);
void UART_Configuration (void);
#ifdef __cplusplus
}
#endif

#endif
