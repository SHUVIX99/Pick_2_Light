#include "button.h"
extern GPIO_InitTypeDef 					GPIO_InitStructure;
void Button_Configure(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}
uint8_t Read_Button(void)
{
	return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15);
}
void Led_red_on(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_8,(BitAction)(1));
}
void Led_red_off(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_8,(BitAction)(0));
}
