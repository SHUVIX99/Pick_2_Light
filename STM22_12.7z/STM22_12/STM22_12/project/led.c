#include "led.h"
#include "common.h"
extern GPIO_InitTypeDef 					GPIO_InitStructure;
#define time_led 1
uint8_t a[9];
void ID_Staff(uint16_t num)
{
//	uint8_t a0,a1,a2,a3;
	if(num<10000)
	{
		a[0]=num/1000;
		a[1]=(num/100)%10;
		a[2]=(num/10)%10;
		a[3]=num%10;
//		a3=num/1000;
//		a2=(num/100)%10;
//		a1=(num/10)%10;
//		a0=num%10;
//		LED_ON(LED1);
//		Single(a3);
//		Delay_ms(time_led);
//		LED_ON(LED2);
//		Single(a2);
//		Delay_ms(time_led);
//		LED_ON(LED3);
//		Single(a1);
//		Delay_ms(time_led);
//		LED_ON(LED4);
//		Single(a0);
//		Delay_ms(time_led);
	}
}
void Num_Product(uint16_t num)
{
//	uint8_t a0,a1,a2,a3;
	if(num<10000)
	{
		a[4]=num/1000;
		a[5]=(num/100)%10;
		a[6]=(num/10)%10;
		a[7]=num%10;
		
//		a3=num/1000;
//		a2=(num/100)%10;
//		a1=(num/10)%10;
//		a0=num%10;
//		LED_ON(LED5);
//		Single(a3);
//		Delay_ms(time_led);
//		LED_ON(LED6);
//		Single(a2);
//		Delay_ms(time_led);
//		LED_ON(LED7);
//		Single(a1);
//		Delay_ms(time_led);
//		LED_ON(LED8);
//		Single(a0);
//		Delay_ms(time_led);
	}
}
void LED_OFF(void)
{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
}
void Single(uint8_t num)
{
	if(num==9)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
	else if(num==8)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
		else if(num==7)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(1));
	}
	else if(num==6)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}	
	else if(num==5)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
	else if(num==4)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
		else if(num==3)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
	else if(num==2)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(0));
	}
		else if(num==1)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(1));
	}
	else if(num==0)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_4,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_6,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_7,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(1));
	}
}	
void GPIO_Configuration_LED(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	AFIO->MAPR |= (0x02<<24);
	AFIO->MAPR |= (0x00<<13)|(0x00<<14);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_0 |GPIO_Pin_1|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4 |GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9 |GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);



}
void LED_ON(LED_7_Seg ledon)
{
	if(ledon==LED8)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
	else if(ledon==LED7)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
		else if(ledon==LED6)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(0));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
		else if(ledon==LED5)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(0));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
			else if(ledon==LED4)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(0));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
			else if(ledon==LED3)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(0));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
			else if(ledon==LED2)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(0));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(1));
	}
			else if(ledon==LED1)
	{
		GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)(1));
		GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_0,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_1,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_2,(BitAction)(1));
		GPIO_WriteBit(GPIOA,GPIO_Pin_3,(BitAction)(0));
	}
}
