#include "CAN.h" 
#include "stdio.h"

extern GPIO_InitTypeDef 					GPIO_InitStructure;
extern NVIC_InitTypeDef 					NVIC_InitStructure;
uint16_t CAN_ID_Receive;
uint8_t CAN_DATA_Receive[8];
/////////////////////////
#define ID_GateWay 0x10
uint16_t ID_Module=0x13;
//uint8_t positive_message_response_1[8] ={0x26,0x21};
//uint8_t positive_message_response_2[8] ={0x27,0x22};
//uint8_t negative_message_response_1[8] ={0x26,0x23};
//uint8_t negative_message_response_2[8] ={0x27,0x24};
uint8_t over_message_response[8] ={0x28,0x25};
uint8_t First_Data=ENABLE;
uint8_t RFID_Flag=ENABLE;
uint8_t in_dex=0;
///
uint16_t id_staff_temp,num_product_temp;
uint8_t inorout_temp;
uint8_t id_rfid[5];
///
Message_Can mess_can[4];

//
	uint8_t timeout_CAN;
	uint8_t timeout_can;
// 
	uint8_t newdata=0;
	uint16_t time_newdata=0;

void USB_LP_CAN1_RX0_IRQHandler(void)
{
	CanRxMsg RxMessage;
	CAN_Receive(CAN1,CAN_FIFO0, &RxMessage);
	CAN_ID_Receive=RxMessage.StdId;
	CAN_DATA_Receive[0]=RxMessage.Data[0];
	CAN_DATA_Receive[1]=RxMessage.Data[1];
	CAN_DATA_Receive[2]=RxMessage.Data[2];
	CAN_DATA_Receive[3]=RxMessage.Data[3];
	CAN_DATA_Receive[4]=RxMessage.Data[4];
	CAN_DATA_Receive[5]=RxMessage.Data[5];
	CAN_DATA_Receive[6]=RxMessage.Data[6];
	CAN_DATA_Receive[7]=RxMessage.Data[7];
	CAN_ClearITPendingBit(CAN1,CAN_IT_FMP0);
	printf("CAN Receive Data: %x : %x  %x  %x  %x  %x  %x  %x  %x \r\n",CAN_ID_Receive,CAN_DATA_Receive[0],CAN_DATA_Receive[1],CAN_DATA_Receive[2],CAN_DATA_Receive[3],CAN_DATA_Receive[4],CAN_DATA_Receive[5],CAN_DATA_Receive[6],CAN_DATA_Receive[7]);

	if(CAN_ID_Receive ==ID_Module)
	{

		if(First_Data==ENABLE)
			{
				
				// 0x01 0 id_staff 0x02 inorout numpro numpro 0x03
				if((CAN_DATA_Receive[0]==0x01) && (CAN_DATA_Receive[3]==0x02) && (CAN_DATA_Receive[7]==0x03))
				{
					newdata=1;
					time_newdata=0;
					printf("Newdata\r\n");
					if(in_dex==4)
					{
							over_message_response[3]=(uint8_t)ID_Module;
							over_message_response[2]=(uint8_t)(ID_Module>>8);
							CanWriteData(ID_GateWay,over_message_response,4);
							printf("___________Over_mess_\r\n");
					}
					else
					{


						id_staff_temp=CAN_DATA_Receive[2];
						inorout_temp=CAN_DATA_Receive[4];
						num_product_temp=CAN_DATA_Receive[6];
						num_product_temp|=CAN_DATA_Receive[5]<<8;
						First_Data =DISABLE;
						printf("___________positive_1\r\n");
					}
				}
				else
				{

					printf("___________negative_1\r\n");
				}
			}
		if(	First_Data ==DISABLE)
		{
			
		// 0x04  id+staff rifd rfid rfid rfid rfid 0x05
			//&& (id_staff_temp>>8)==CAN_DATA_Receive[1] && (id_staff_temp&0x00FF) ==CAN_DATA_Receive[2]
			if(CAN_DATA_Receive[0]==0x04  && CAN_DATA_Receive[7]==0x05)
				{
					mess_can[in_dex].id_rfid[0]= CAN_DATA_Receive[2];
					mess_can[in_dex].id_rfid[1]= CAN_DATA_Receive[3];
					mess_can[in_dex].id_rfid[2]= CAN_DATA_Receive[4];
					mess_can[in_dex].id_rfid[3]= CAN_DATA_Receive[5];
					mess_can[in_dex].id_rfid[4]= CAN_DATA_Receive[6];

					mess_can[in_dex].id_staff=id_staff_temp;
					mess_can[in_dex].inorout=inorout_temp;
					mess_can[in_dex].num_product=num_product_temp;
					in_dex++;
//					printf("ID_Staff2:%d\r\n",mess_can[0].id_staff);
//					printf("ID_Staff3:%d\r\n",mess_can[1].id_staff);
//					printf("ID_Staff4:%d\r\n",mess_can[2].id_staff);
//					printf("ID_Staff5:%d\r\n",mess_can[3].id_staff);
					soft_struct_id();
//					printf("ID_Staff2:%d\r\n",mess_can[0].id_staff);
//					printf("ID_Staff3:%d\r\n",mess_can[1].id_staff);
//					printf("ID_Staff4:%d\r\n",mess_can[2].id_staff);
//					printf("ID_Staff5:%d\r\n",mess_can[3].id_staff);

					First_Data=ENABLE;
					
				}
				else
				{
				}
		}
		soft_struct_id();
	}
}
void soft_struct_id(void)
{
	uint16_t id_staff_temp;
	uint16_t num_product_temp;
	uint8_t id_rfid_temp[5];
	uint8_t inorout_temp;
	int8_t i,j;
		for(i=1;i<4;i++)
	{
		id_staff_temp=mess_can[i].id_staff;
		num_product_temp=mess_can[i].num_product;
		inorout_temp=mess_can[i].inorout;
		id_rfid_temp[0]=mess_can[i].id_rfid[0];
		id_rfid_temp[1]=mess_can[i].id_rfid[1];
		id_rfid_temp[2]=mess_can[i].id_rfid[2];
		id_rfid_temp[3]=mess_can[i].id_rfid[3];
		id_rfid_temp[4]=mess_can[i].id_rfid[4];
		j=i-1;
		while((j>=0) && ((mess_can[j].id_staff) < id_staff_temp) )
		{
			mess_can[j+1].id_staff=mess_can[j].id_staff;
			mess_can[j+1].id_rfid[0]=mess_can[j].id_rfid[0];
			mess_can[j+1].id_rfid[1]=mess_can[j].id_rfid[1];
			mess_can[j+1].id_rfid[2]=mess_can[j].id_rfid[2];
			mess_can[j+1].id_rfid[3]=mess_can[j].id_rfid[3];
			mess_can[j+1].id_rfid[4]=mess_can[j].id_rfid[4];
			mess_can[j+1].inorout=mess_can[j].inorout;
			mess_can[j+1].num_product=mess_can[j].num_product;
			j=j-1;
		}
		mess_can[j+1].id_staff=id_staff_temp;
		mess_can[j+1].id_rfid[0]=id_rfid_temp[0];
		mess_can[j+1].id_rfid[1]=id_rfid_temp[1];
		mess_can[j+1].id_rfid[2]=id_rfid_temp[2];
		mess_can[j+1].id_rfid[3]=id_rfid_temp[3];
		mess_can[j+1].id_rfid[4]=id_rfid_temp[4];
		mess_can[j+1].inorout=inorout_temp;
		mess_can[j+1].num_product=num_product_temp;
	}
	
}
void clear_struct(uint8_t i)
{
	mess_can[i].id_rfid[0]=0;
	mess_can[i].id_rfid[1]=0;
	mess_can[i].id_rfid[2]=0;
	mess_can[i].id_rfid[3]=0;
	mess_can[i].id_rfid[4]=0;
	mess_can[i].id_staff=0;
	mess_can[i].num_product=0;
	in_dex--;
	soft_struct_id();
}
uint8_t Check_Mess_can()
{

		if(mess_can[0].id_staff !=0) return 1;
	else return 0;

}
void CAN_Configuration(void)
{
  CAN_InitTypeDef        CAN_InitStructure;
  CAN_FilterInitTypeDef  CAN_FilterInitStructure;

	  /* CAN Periph clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA ,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO ,ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

  /* Configure CAN pin: RX */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);   
  /* Configure CAN pin: TX */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);	

  /* CAN register init */
  CAN_DeInit(CAN1);
  CAN_StructInit(&CAN_InitStructure);

  /* CAN cell init */
  CAN_InitStructure.CAN_TTCM = DISABLE;  // ??????????
  CAN_InitStructure.CAN_ABOM = ENABLE; // enalbe
  CAN_InitStructure.CAN_AWUM = ENABLE;  // enable
  CAN_InitStructure.CAN_NART = DISABLE;
  CAN_InitStructure.CAN_RFLM = DISABLE;
  CAN_InitStructure.CAN_TXFP = DISABLE;
  CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
  CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
  CAN_InitStructure.CAN_BS1 = CAN_BS1_4tq;
  CAN_InitStructure.CAN_BS2 = CAN_BS2_3tq;
  CAN_InitStructure.CAN_Prescaler = 9;


  if (CAN_Init(CAN1,&CAN_InitStructure) == CANINITFAILED) 		
  {
//		printf("CAN FAILED");
  }	

	CAN_FilterInitStructure.CAN_FilterNumber=1;
  CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;  // MASK MODE or LIST MODE FBMx
  CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //32 or 16  Filter FSCx
  CAN_FilterInitStructure.CAN_FilterIdHigh=0x0;  
  CAN_FilterInitStructure.CAN_FilterIdLow=0;
  CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0;
  CAN_FilterInitStructure.CAN_FilterMaskIdLow=0;
  CAN_FilterInitStructure.CAN_FilterFIFOAssignment=0; //FIFO0 or FIF01
  CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //Enable
  CAN_ITConfig(CAN1,CAN_IT_FMP0, ENABLE);
  CAN_FilterInit(&CAN_FilterInitStructure);

//	CAN_FilterInitStructure.CAN_FilterNumber=1;
//  CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;  // MASK MODE or LIST MODE FBMx
//  CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //32 or 16  Filter FSCx
//  CAN_FilterInitStructure.CAN_FilterIdHigh=0x120;  
//  CAN_FilterInitStructure.CAN_FilterIdLow=0;
//  CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0xFFE0;
//  CAN_FilterInitStructure.CAN_FilterMaskIdLow=0;
//  CAN_FilterInitStructure.CAN_FilterFIFOAssignment=0; //FIFO0 or FIF01
//  CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //Enable
//  CAN_ITConfig(CAN1,CAN_IT_FMP0, ENABLE);
//  CAN_FilterInit(&CAN_FilterInitStructure);
}
uint8_t CanWriteData(uint16_t ID,uint8_t *CAN_DATA,uint8_t length)
{
  CanTxMsg TxMessage;
	uint8_t result=0;
	uint8_t Txmail=0;
  /* transmit */
  TxMessage.StdId = ID;
//TxMessage.ExtId = 0x00;
  TxMessage.RTR = CAN_RTR_DATA;
  TxMessage.IDE = CAN_ID_STD;
  TxMessage.DLC = length;
  TxMessage.Data[0] = CAN_DATA[0];    
  TxMessage.Data[1] = CAN_DATA[1];    
  TxMessage.Data[2] = CAN_DATA[2];    
  TxMessage.Data[3] = CAN_DATA[3];    
  TxMessage.Data[4] = CAN_DATA[4];    
  TxMessage.Data[5] = CAN_DATA[5];     
  TxMessage.Data[6] = CAN_DATA[6];    
  TxMessage.Data[7] = CAN_DATA[7]; 
	timeout_CAN=0;
//		while(timeout_CAN<50)
//			{
//				if(timeout_can>9)
//				{
					Txmail=CAN_Transmit(CAN1,&TxMessage);
//					printf("Tmail%d\r\n",Txmail);
					if(CAN_TransmitStatus(CAN1,Txmail)==CAN_TxStatus_Ok)
						{
//							printf("Succcues\r\n");
							result=1;
							CAN_CancelTransmit(CAN1,0);
							CAN_CancelTransmit(CAN1,1);
							CAN_CancelTransmit(CAN1,2);
							
//							break;
						}
						else
						{	result=0;	}
				//}
//			}
  
	return result;
}


void NVIC_CAN_Configuration(void)
{

  /* Enable CAN1 RX0 interrupt IRQ channel */
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}
